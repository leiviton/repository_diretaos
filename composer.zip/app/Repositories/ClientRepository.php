<?php

namespace CodeDelivery\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ClientRepository
 * @package namespace CodeDelivery\Repositories;
 */
interface ClientRepository extends RepositoryInterface
{
    //
}
