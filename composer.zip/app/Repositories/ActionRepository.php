<?php

namespace CodeDelivery\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ActionRepository
 * @package namespace CodeDelivery\Repositories;
 */
interface ActionRepository extends RepositoryInterface
{
    //
}
