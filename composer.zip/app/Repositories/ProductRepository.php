<?php

namespace CodeDelivery\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ProductRepository
 * @package namespace CodeDelivery\Repositories;
 */
interface ProductRepository extends RepositoryInterface
{
    //
}
