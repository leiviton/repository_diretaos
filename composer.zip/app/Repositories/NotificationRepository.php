<?php

namespace CodeDelivery\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface NotificationRepository
 * @package namespace CodeDelivery\Repositories;
 */
interface NotificationRepository extends RepositoryInterface
{
    //
}
