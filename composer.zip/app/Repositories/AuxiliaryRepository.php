<?php

namespace CodeDelivery\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AuxiliaryRepository
 * @package namespace CodeDelivery\Repositories;
 */
interface AuxiliaryRepository extends RepositoryInterface
{
    //
}
