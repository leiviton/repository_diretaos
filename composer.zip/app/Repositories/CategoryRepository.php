<?php

namespace CodeDelivery\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CategoryRepository
 * @package namespace CodeDelivery\Repositories;
 */
interface CategoryRepository extends RepositoryInterface
{
    //
}
