<?php

namespace CodeDelivery\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AuxuliaryItemsRepository
 * @package namespace CodeDelivery\Repositories;
 */
interface AuxiliaryItemsRepository extends RepositoryInterface
{
    //
}
