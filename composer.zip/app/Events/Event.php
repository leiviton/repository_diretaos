<?php

namespace CodeDelivery\Events;

abstract class Event
{
    //
}
