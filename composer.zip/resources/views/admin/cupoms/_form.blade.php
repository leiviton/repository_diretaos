<div class="form-group col-md-4">
    {!! Form::label('Codigo','Código:') !!}
    {!! Form::text('code',null,['class'=>'form-control']) !!}
</div>
<div class="clearfix"></div>
<div class="form-group col-md-2">
    {!! Form::label('Valor','Valor:') !!}
    {!! Form::text('value',null,['class'=>'form-control']) !!}
</div>